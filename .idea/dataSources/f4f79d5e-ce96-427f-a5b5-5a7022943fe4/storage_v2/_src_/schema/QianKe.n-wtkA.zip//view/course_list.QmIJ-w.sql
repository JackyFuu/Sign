create view course_list as
  select
    `s`.`student_num`       AS `student_num`,
    `tt`.`teaching_task_id` AS `teaching_task_id`,
    `te`.`teacher_name`     AS `teacher_name`,
    `c`.`course_name`       AS `course_name`,
    `c`.`course_image`      AS `course_image`,
    `t`.`week_time`         AS `week_time`,
    `t`.`class_time`        AS `class_time`,
    `t`.`start_time`        AS `start_time`,
    `t`.`course_length`     AS `course_length`,
    `t`.`teaching_place`    AS `teaching_place`
  from `QianKe`.`student` `s`
    join `QianKe`.`select_course` `sc`
    join `QianKe`.`teacher` `te`
    join `QianKe`.`teaching_task` `tt`
    join `QianKe`.`teaching` `t`
    join `QianKe`.`course` `c`
  where ((`s`.`student_id` = `sc`.`student_id`) and (`tt`.`teaching_task_id` = `sc`.`teaching_task_id`) and
         (`te`.`teacher_id` = `tt`.`teacher_id`) and (`tt`.`teaching_task_id` = `t`.`teaching_task_id`) and
         (`tt`.`course_id` = `c`.`course_id`));

